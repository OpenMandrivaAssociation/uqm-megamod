You're looking at the readme for 'The Ur-Quan Masters', a volunteer
project that intends to bring the classic game 'Star Control II' to
modern systems.

The program code that comprises 'The Ur-Quan Masters' was derived from code
written by Toys for Bob, Inc. for the 3DO version of 'Star Control II', with
their permission and encouragement.

If you've got this file from the source tree, you can find everything
you need to get started in INSTALL. Additionally and depending on your
platform, please see:
  INSTALL.mingw    for MinGW build instructions
  INSTALL.msvc     for MSVC++ build instructions
  INSTALL.macosx   for MacOS X build instructions
  INSTALL.symbian  for Symbian build instructions
  doc/users/unixinstall

The home page of the project is located at http://sc2.sourceforge.net/
You can find links to downloads, our bug database, and our forum there.

Have fun!


Star Control II is a registered trademark of Accolade, Inc.
All other trademarks and tradenames belong to their respective owners.

