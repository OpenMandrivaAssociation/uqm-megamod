#if defined(__cplusplus)
extern "C" {
#endif

#include "callback/alarm.h"

#if defined(__cplusplus)
}
#endif
